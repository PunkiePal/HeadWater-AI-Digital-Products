#!/usr/bin/env python3
"""
HeadWater Data Preparation Engine - runnable demo

Run it on the sample files, or on your own folder of text files:

    python3 demo.py sample_input
    python3 demo.py my_folder --output my_results

It shows the main steps the full engine performs on every file:
  1. clean formatting (line endings, tabs, repeated spaces, blank lines)
  2. standardize company names (drop Inc., LLC, Corp. and so on)
  3. standardize system parameter lines
  4. flag text that looks like AI instructions, and hidden characters
  5. record everything, including failures, in a JSON report

This is a demo edition. It is limited to 15 files per run and 100 KB per
file, and uses a shorter rule list than the full product. The full engine
adds the desktop window, no demo limits, the complete rule set, the user
guide and the qualification record.

Needs Python 3.8 or newer. Nothing to install.
"""
import argparse
import hashlib
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

MAX_FILES = 15
MAX_BYTES = 100_000
TYPES = {".txt", ".md", ".csv", ".json", ".xml", ".html", ".htm"}
SUFFIXES = ["Limited Liability Company", "Incorporated", "Corporation",
            "L.L.C.", "Corp.", "Corp", "Inc.", "Inc", "LLC"]
FLAG_PHRASES = [r"ignore\s+(all\s+)?(previous|prior)\s+instructions",
                r"system\s+prompt", r"jailbreak"]
HIDDEN = (set(range(0x200B, 0x2010)) | set(range(0x202A, 0x202F))
          | set(range(0x2060, 0x2065)))


def utc():
    return datetime.now(timezone.utc).isoformat()


def clean_format(text):
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = re.sub(r"[ \t]+", " ", text)
    return re.sub(r"\n{3,}", "\n\n", text)


def clean_companies(text, changes):
    suffix = "|".join(re.escape(s) for s in SUFFIXES)
    pattern = re.compile(rf"\b([A-Z][A-Za-z0-9&' -]{{1,60}}?) (?:{suffix})(?=\s|[,.!?;:]|$)")

    def drop(m):
        changes.append({"type": "company_name", "from": m.group(0), "to": m.group(1)})
        return m.group(1)
    return pattern.sub(drop, text)


def clean_parameters(text, changes):
    pattern = re.compile(r"\b([A-Za-z][A-Za-z0-9]*(?:[ \t_-]+[A-Za-z0-9]+){1,8})[ \t]*=[ \t]*([\w.:/-]+)")

    def fix(m):
        words = re.split(r"[ \t_-]+", m.group(1))
        if not any(w.lower() in ("system", "parameter", "param") for w in words):
            return m.group(0)
        new = "_".join(w.upper() for w in words) + "=" + m.group(2)
        if new != m.group(0):
            changes.append({"type": "system_parameter", "from": m.group(0), "to": new})
        return new
    return pattern.sub(fix, text)


def flag(text):
    found = [{"type": "ai_instruction_text"} for p in FLAG_PHRASES
             if re.search(p, text, re.IGNORECASE)]
    chars = sorted({f"U+{ord(c):04X}" for c in text if ord(c) in HIDDEN})
    if chars:
        found.append({"type": "hidden_characters", "characters": chars})
    return found


def process(path, root, out):
    rel = path.relative_to(root)
    item = {"file": str(rel), "status": "failed", "errors": [], "warnings": [],
            "changes": [], "flags": [], "output": None}
    if path.suffix.lower() not in TYPES:
        item["errors"].append(f"Unsupported file type: {path.suffix or 'none'}")
        return item
    try:
        raw = path.read_bytes()
    except OSError as exc:
        item["errors"].append(f"Unable to read file: {exc}")
        return item
    if not raw:
        item["errors"].append("File is empty.")
        return item
    if len(raw) > MAX_BYTES:
        item["errors"].append(f"Demo limit: files over {MAX_BYTES // 1000} KB are skipped.")
        return item
    item["sha256"] = hashlib.sha256(raw).hexdigest()
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        text = raw.decode("utf-8", errors="replace")
        item["warnings"].append("Bad UTF-8 bytes were replaced.")
    cleaned = clean_format(text)
    if cleaned != text:
        item["changes"].append({"type": "formatting"})
    cleaned = clean_companies(cleaned, item["changes"])
    cleaned = clean_parameters(cleaned, item["changes"])
    item["flags"] = flag(cleaned)
    dest = out / "processed_data" / rel.parent / f"{path.stem}_processed.txt"
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(cleaned, encoding="utf-8", newline="\n")
    item["output"] = str(dest.relative_to(out))
    item["status"] = "successful"
    return item


def main():
    ap = argparse.ArgumentParser(description="HeadWater Data Preparation Engine - demo")
    ap.add_argument("input", help="File or folder to process")
    ap.add_argument("--output", default="demo_output", help="Where results go")
    args = ap.parse_args()
    src, out = Path(args.input), Path(args.output)
    if not src.exists():
        print(f"Not found: {src}")
        return 2
    root = src if src.is_dir() else src.parent
    files = [src] if src.is_file() else sorted(p for p in src.rglob("*") if p.is_file())
    skipped = files[MAX_FILES:]
    files = files[:MAX_FILES]
    started = utc()
    results = [process(f, root, out) for f in files]
    ok = sum(r["status"] == "successful" for r in results)
    report = {"tool": "HeadWater Data Preparation Engine - demo edition",
              "started_utc": started, "completed_utc": utc(), "input": str(src),
              "summary": {"files_processed": len(results), "successful": ok,
                          "failed": len(results) - ok,
                          "changes": sum(len(r["changes"]) for r in results),
                          "flags": sum(len(r["flags"]) for r in results),
                          "skipped_over_demo_limit": len(skipped)},
              "results": results}
    (out / "reports").mkdir(parents=True, exist_ok=True)
    rf = out / "reports" / "demo_report.json"
    rf.write_text(json.dumps(report, indent=2), encoding="utf-8")

    print(f"\nHeadWater Data Preparation Engine - demo edition\n{'-' * 52}")
    for r in results:
        if r["status"] == "successful":
            notes = []
            n = sum(c["type"] != "formatting" for c in r["changes"])
            if any(c["type"] == "formatting" for c in r["changes"]):
                notes.append("cleaned formatting")
            if n:
                notes.append(f"{n} name/setting fixes")
            if r["flags"]:
                notes.append("FLAGGED for review")
            print(f"  ok      {r['file']}  ({', '.join(notes) or 'no changes needed'})")
        else:
            print(f"  FAILED  {r['file']}  ({r['errors'][0]})")
    s = report["summary"]
    print(f"{'-' * 52}\n{s['successful']} successful, {s['failed']} failed, "
          f"{s['changes']} changes, {s['flags']} flags")
    if skipped:
        print(f"Demo limit: {len(skipped)} more file(s) not processed (max {MAX_FILES}).")
    print(f"Cleaned files: {out / 'processed_data'}\nReport: {rf}\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
