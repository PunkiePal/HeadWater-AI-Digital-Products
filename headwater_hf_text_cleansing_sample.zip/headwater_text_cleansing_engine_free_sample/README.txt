HeadWater Text Cleansing Engine
Free Sample: Before and After

This is a free look at what the HeadWater Text Cleansing Engine does to a
text file. There are six small example files in two folders:

    before/    the example files as they start out
    after/     the same files after the engine cleaned them

The files in after/ are real output from the engine. This sample shows
results only. It does not include the engine, so there is nothing to run.
Open a file in before/ next to the one in after/ to see the difference.


WHAT THE ENGINE DOES

The engine reads one UTF-8 text file, cleans it line by line, and writes a
new cleaned file. Your original is not changed. It makes these changes:

  1. Removes spaces and tabs at the start and end of every line, so
     indentation goes too.
  2. Removes "Inc", "LLC" or "Corp" from the end of a line (any
     capitalization, with or without a full stop), along with the space or
     comma before it.
  3. Cuts every line to its first 250 characters.
  4. Makes every kind of line break the same plain one.
  5. Makes sure the file ends with a line break.

Everything else is left alone: words, numbers, punctuation, spaces inside a
line, and text in other languages.


THE EXAMPLES

01_company_names.txt
    Company endings are removed from the end of a line, whatever the
    capitalization and punctuation. Lines where the ending is not at the
    end are left alone, and so is a line that is just "Corp".
      "Acme Corp"
   -> "Acme"
      "Globex, LLC"
   -> "Globex"
      "Initech Inc."
   -> "Initech"
      "Hooli inc"
   -> "Hooli"
      "Smith & Sons, LLC."
   -> "Smith & Sons"
    Left as they were:
      "Acme Corp signed the contract on Friday."
      "Corp"

02_spacing.txt
    Spaces and tabs at the ends of each line go, indentation included.
    Spaces inside a line stay. One list item ends in "Inc", which is removed too.
      "    Attendees:   Jordan,  Priya   "
   -> "Attendees:   Jordan,  Priya"
      "	Action items	"
   -> "Action items"
      "        - send the quote to Globex Inc   "
   -> "- send the quote to Globex"
      "        - confirm the delivery date   "
   -> "- confirm the delivery date"

03_line_breaks.txt
    This file mixes three kinds of line break: Windows, old Mac and Unix.
    In after/ they are all the same. The blank line is kept. The engine
    writes the same plain line breaks on every system.

04_long_line.txt
    Short lines are never touched. A line longer than 250 characters is
    cut at the 250th character, and the rest is lost. The engine gives no
    warning when it does this. In this file the long line is 308
    characters. After cleaning, it is exactly 250, and ends here:
      ..."t is lost and this sentence will be cut off s"

05_other_languages.txt
    Text in other languages passes through unchanged. Only the company
    endings at the end of a line are removed.
      "日本語のメモ Inc"
   -> "日本語のメモ"
      "Привет мир Corp."
   -> "Привет мир"

06_csv_rows.csv
    The engine works on plain text, one line at a time. It does not read
    columns. A company ending in the middle of a row is not at the end of
    the line, so it stays. Only lines that end with one are changed.
      "Vendor: Hooli Corp"
   -> "Vendor: Hooli"
      "Contact is Pied Piper, Inc."
   -> "Contact is Pied Piper"
    Left as they were:
      "Globex LLC,Reno,active"
      "Initech Inc,Austin,active"


GOOD TO KNOW BEFORE YOU USE IT

  - It removes "Inc", "LLC" or "Corp" from the end of ANY line, not only
    lines that are company names.
  - Cutting long lines is silent. Check your data for lines over 250
    characters.
  - It cleans one file per run, and it does not write a report.
  - The input must be valid UTF-8 text. Other encodings are rejected.
  - Check the output before you rely on it.


THE FULL ENGINE

The full HeadWater Text Cleansing Engine is a Python tool (Python 3.10 or
newer, nothing else to install). It runs from the command line and also
has a simple window for choosing files. It comes with a user guide, a
testing record and a commercial license. Tested on Linux with Python 3.10
to 3.13, and on Windows (GitHub's Windows test machine) with Python 3.10
and 3.13. Not tested on macOS.

  Product page: https://github.com/PunkiePal/HeadWater-AI-Digital-Products/blob/main/headwater_text_cleansing_engine.md
  Buy it on Payhip: https://payhip.com/b/vmcjQ


LICENSE

This free sample is covered by the HeadWater Free Sample License, Version
1.1. The full text is in this folder in HEADWATER_FREE_SAMPLE_LICENSE.md,
and online at:
https://github.com/PunkiePal/HeadWater-AI-Digital-Products/blob/main/HEADWATER_FREE_SAMPLE_LICENSE.md

You can download, use and share this sample for free. If you share it,
share the complete package unchanged and free of charge. It is not
open-source software. The full engine has its own separate license.


QUESTIONS

headwateraistudio@outlook.com
