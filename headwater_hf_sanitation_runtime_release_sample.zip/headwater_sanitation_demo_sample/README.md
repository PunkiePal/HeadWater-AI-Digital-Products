# HeadWater Live System Sanitation Runtime Engine - Demonstration Sample

This is a free demonstration of what the HeadWater Live System Sanitation Runtime Engine does to a text file. You can run it on your own computer in a minute and see the results for yourself.

This sample is a small stand-alone demo. It is not the full product, and it does not include the product's launcher, desktop window, or runtime engine files.

## What the demo shows

The sanitation gateway looks at a UTF-8 text file and does three things:

1. It removes hidden characters and control characters, such as zero-width spaces and the bell character. Normal line breaks and tabs are kept.
2. It normalizes look-alike characters. For example, full-width letters and ligatures are converted to their plain forms.
3. It counts the words. Text with 400 words or fewer is **ACCEPTED** and the clean text is saved. Text with more than 400 words is **REJECTED** and nothing is saved.

## What you need

- Python 3.8 or newer
- Nothing else. The demo runs in a terminal and does not need a desktop window or any extra packages.

## How to run it

Unzip the folder, open a terminal inside it, and run one of these.

Ubuntu/Linux:

    python3 demo.py

Windows:

    py -3 demo.py

The demo runs all six included samples and prints the input, the result, and the clean output for each one. Accepted results are also saved as files in a folder named `demo_output`.

## The included samples

The input files are in `samples/input`. The results recorded from the real engine are in `samples/expected`.

| File | What it shows | Result |
| --- | --- | --- |
| 01_clean_text.txt | Normal text that needs no changes | ACCEPTED |
| 02_hidden_characters.txt | Hidden zero-width and invisible characters inside words | ACCEPTED, 6 characters removed |
| 03_control_characters.txt | Control characters mixed into the text | ACCEPTED, 6 characters removed |
| 04_unicode_normalization.txt | Full-width letters, ligatures, and circled numbers | ACCEPTED, 18 characters normalized |
| 05_exactly_400_words.txt | Exactly 400 words, the largest size allowed | ACCEPTED |
| 06_over_limit_401_words.txt | 401 words, one word over the limit | REJECTED |

Some viewers show a warning when they open `02_hidden_characters.txt` because it contains hidden characters. That is on purpose.

## Try your own text

Run the demo on any UTF-8 text file:

    python3 demo.py myfile.txt

On Windows, use `py -3 demo.py myfile.txt`.

The demo prints the result and saves a clean copy to `demo_output` if the text is accepted. If the file is missing or is not valid UTF-8 text, the demo says so and produces no output.

## Check that the demo works

    python3 demo.py --self-check

This runs the six samples and compares each one with the recorded result. You should see `6 of 6 samples match the recorded results.`

## About this sample

- The 400-word limit is the same limit the full product uses.
- The demo reports the word count after hidden characters are removed, the same way the full product does.
- The full product adds a launcher, a desktop interface with file selection and status display, and a license for business use.

## Get the full engine

This is a free sample. The full engine is a separate product.

- Product page: https://github.com/PunkiePal/HeadWater-AI-Digital-Products/blob/main/HeadWater%20Live%20System%20Sanitation%20Runtime%20Engine.md
- Buy it on Payhip: https://payhip.com/b/P6XZE
- Questions: headwateraistudio@outlook.com

## License

This sample is covered by the HeadWater Free Sample License, Version 1.0. The full text is in this package in `HEADWATER_FREE_SAMPLE_LICENSE.md`, and online at https://github.com/PunkiePal/HeadWater-AI-Digital-Products/blob/main/HEADWATER_FREE_SAMPLE_LICENSE.md

You can download, use and share this sample for free. If you share it, share the complete package unchanged and free of charge. It is not open-source software. The full engine has its own separate license.
