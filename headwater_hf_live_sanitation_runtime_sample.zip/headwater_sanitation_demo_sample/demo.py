#!/usr/bin/env python3
"""HeadWater Live System Sanitation Runtime Engine - demonstration sample.

This script shows what the sanitation gateway does to a text file:

  1. It removes hidden and control characters. Line breaks and tabs stay.
  2. It normalizes look-alike characters, such as full-width letters.
  3. It counts the words. Text with 400 words or fewer is ACCEPTED.
     Text with more than 400 words is REJECTED and no output is produced.

This is a small stand-alone demonstration. It is not the commercial product.

Usage:
  python3 demo.py                 run all included samples
  python3 demo.py --self-check    check the demo against the recorded results
  python3 demo.py myfile.txt      run the demo on your own UTF-8 text file
"""
import argparse
import json
import sys
import unicodedata
from pathlib import Path

WORD_LIMIT = 400
HERE = Path(__file__).resolve().parent
SAMPLE_DIR = HERE / "samples" / "input"
EXPECTED_DIR = HERE / "samples" / "expected"
DEFAULT_OUT_DIR = HERE / "demo_output"
KEEP_AS_IS = ("\n", "\r", "\t")
PREVIEW_LIMIT = 400


def sanitize(text):
    """Return (clean_text, removed_count, normalized_count)."""
    survivors = []
    removed = 0
    for ch in text:
        if ch not in KEEP_AS_IS and unicodedata.category(ch) in ("Cc", "Cf"):
            removed += 1
        else:
            survivors.append(ch)

    pieces = []
    normalized = 0
    for ch in survivors:
        plain = unicodedata.normalize("NFKC", ch)
        if plain != ch:
            normalized += 1
        pieces.append(plain)
    return "".join(pieces), removed, normalized


def evaluate(path):
    """Run the demonstration gateway on one file and return a result dictionary."""
    result = {
        "status": "error",
        "word_count": 0,
        "word_limit": WORD_LIMIT,
        "boundary_result": "not_evaluated",
        "modified": False,
        "reason": "",
        "controlled_text": "",
        "removed": 0,
        "normalized": 0,
        "original_text": "",
    }
    try:
        raw = Path(path).read_bytes()
    except FileNotFoundError:
        result["reason"] = "file not found"
        return result
    except OSError as problem:
        result["reason"] = "could not read the file (%s)" % (problem.strerror or "unknown error")
        return result
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        result["reason"] = "the file is not valid UTF-8 text"
        return result

    clean, removed, normalized = sanitize(text)
    words = len(clean.split())
    result.update(
        word_count=words,
        modified=bool(removed or normalized),
        removed=removed,
        normalized=normalized,
        original_text=text,
    )
    if words > WORD_LIMIT:
        result.update(
            status="rejected",
            boundary_result="failed",
            reason="exceeds %d word boundary" % WORD_LIMIT,
        )
    else:
        result.update(
            status="accepted",
            boundary_result="passed",
            reason="within %d word boundary" % WORD_LIMIT,
            controlled_text=clean,
        )
    return result


def visible(text):
    """Show hidden characters as <U+XXXX> so they can be seen on screen."""
    shown = []
    for ch in text:
        if ch == "\n":
            shown.append("\n")
        elif ch == "\r":
            shown.append("<CR>")
        elif ch == "\t":
            shown.append("<TAB>")
        elif " " <= ch <= "~":
            shown.append(ch)
        else:
            shown.append("<U+%04X>" % ord(ch))
    return "".join(shown)


def indent(text):
    body = text
    if len(body) > PREVIEW_LIMIT:
        body = body[:PREVIEW_LIMIT] + " ... (%d more characters)" % (len(text) - PREVIEW_LIMIT)
    lines = body.rstrip("\n").split("\n") or [""]
    return "\n".join("    " + line for line in lines)


def describe_change(result):
    if not result["modified"]:
        return "no (the text was already clean)"
    parts = []
    if result["removed"]:
        parts.append("%d hidden/control character(s) removed" % result["removed"])
    if result["normalized"]:
        parts.append("%d character(s) normalized" % result["normalized"])
    return "yes - " + ", ".join(parts)


def save_output(path, result, out_dir):
    out_dir.mkdir(parents=True, exist_ok=True)
    target = out_dir / (Path(path).stem + "_sanitized.txt")
    with open(target, "w", encoding="utf-8", newline="") as handle:
        handle.write(result["controlled_text"])
    return target


def show(path, result, out_dir):
    name = Path(path).name
    print("=" * 72)
    print("FILE: " + name)
    print("=" * 72)
    status = result["status"].upper()
    if result["status"] == "error":
        print("RESULT: ERROR - " + result["reason"])
        print("No output was produced.\n")
        return
    print("Input (hidden characters shown as <U+XXXX>):")
    print(indent(visible(result["original_text"])))
    print("")
    print("RESULT:   " + status)
    print("Words:    %d (limit %d)" % (result["word_count"], result["word_limit"]))
    print("Boundary: " + result["boundary_result"])
    print("Changed:  " + describe_change(result))
    if result["status"] == "accepted":
        print("Sanitized output:")
        print(indent(visible(result["controlled_text"])))
        saved = save_output(path, result, out_dir)
        print("Saved to: " + str(saved))
    else:
        print("The text is over the %d word limit, so it was rejected." % WORD_LIMIT)
        print("No sanitized output was produced.")
    print("")


def run_files(paths, out_dir):
    rows = []
    for path in paths:
        result = evaluate(path)
        show(path, result, out_dir)
        rows.append((Path(path).name, result))
    if len(rows) > 1:
        print("-" * 72)
        print("SUMMARY")
        for name, result in rows:
            if result["status"] == "error":
                detail = result["reason"]
            else:
                detail = "%d words, %s" % (result["word_count"], "changed" if result["modified"] else "unchanged")
            print("  %-34s %-9s %s" % (name, result["status"].upper(), detail))
    return 1 if any(r["status"] == "error" for _, r in rows) else 0


COMPARED_FIELDS = ("status", "word_count", "word_limit", "boundary_result", "modified", "reason", "controlled_text")


def self_check():
    inputs = sorted(SAMPLE_DIR.glob("*.txt"))
    if not inputs:
        print("FAIL - no sample files found in " + str(SAMPLE_DIR))
        return 1
    passed = 0
    for path in inputs:
        expected_file = EXPECTED_DIR / (path.stem + ".expected.json")
        try:
            expected = json.loads(expected_file.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            print("FAIL - %s (recorded result is missing or unreadable)" % path.name)
            continue
        actual = evaluate(path)
        wrong = [f for f in COMPARED_FIELDS if actual[f] != expected.get(f)]
        if wrong:
            print("FAIL - %s (differs in: %s)" % (path.name, ", ".join(wrong)))
        else:
            print("PASS - %s -> %s" % (path.name, actual["status"].upper()))
            passed += 1
    print("\n%d of %d samples match the recorded results." % (passed, len(inputs)))
    return 0 if passed == len(inputs) else 1


def main(argv=None):
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass

    parser = argparse.ArgumentParser(
        description="HeadWater sanitation demonstration sample.",
    )
    parser.add_argument("files", nargs="*", help="UTF-8 text file(s) to run. With none, all included samples run.")
    parser.add_argument("--self-check", action="store_true", help="compare the demo with the recorded sample results")
    parser.add_argument("--out-dir", default=str(DEFAULT_OUT_DIR), help="where sanitized output files are saved")
    args = parser.parse_args(argv)

    if args.self_check:
        return self_check()
    paths = args.files or sorted(SAMPLE_DIR.glob("*.txt"))
    if not paths:
        print("No sample files found in " + str(SAMPLE_DIR))
        return 1
    return run_files(paths, Path(args.out_dir))


if __name__ == "__main__":
    sys.exit(main())
