# Vendors

- Contoso Corporation   supplies  parts
- Fabrikam Inc. ships   freight
- Tailspin Corp, our   backup vendor
- Lakeview Limited Liability Company handles    billing
