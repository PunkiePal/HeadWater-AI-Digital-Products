#!/usr/bin/env python3
"""
HeadWater AI Data Ingestion Engine - free demo (lite version)

A small stand-in that shows the SHAPE of what the full engine does:
walk a folder, clean up messy text files, flag suspicious content,
and write a JSON report that records every file, including failures.

The full engine has more cleanup steps (company-name and system-parameter
normalization) and is not included here. See engine_output/ for real
output from the full engine on the same sample files.

Usage:
    python3 demo_lite.py sample_input --output demo_output

Needs Python 3.8+ and nothing else.
"""
import argparse
import hashlib
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

TEXT_TYPES = {".txt", ".md", ".csv", ".json", ".xml", ".html", ".htm"}
SUSPICIOUS = [
    r"ignore\s+(all\s+)?(previous|prior)\s+instructions",
    r"system\s+prompt",
    r"jailbreak",
]
HIDDEN = set(range(0x200B, 0x2010)) | set(range(0x202A, 0x202F)) | set(range(0x2060, 0x2065))


def now():
    return datetime.now(timezone.utc).isoformat()


def clean(text):
    """Fix line endings, repeated spaces/tabs, and runs of blank lines."""
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = re.sub(r"[ \t]+", " ", text)
    return re.sub(r"\n{3,}", "\n\n", text)


def flag(text):
    found = []
    for pattern in SUSPICIOUS:
        if re.search(pattern, text, re.IGNORECASE):
            found.append({"type": "suspicious_instruction_pattern", "pattern": pattern})
    chars = sorted({f"U+{ord(c):04X}" for c in text if ord(c) in HIDDEN})
    if chars:
        found.append({"type": "hidden_character", "characters": chars})
    return found


def handle(path, root, out_root):
    rel = path.relative_to(root)
    item = {"source_file": str(rel), "status": "failed", "errors": [], "warnings": [],
            "suspicious_findings": [], "output_file": None}
    if path.suffix.lower() not in TEXT_TYPES:
        item["errors"].append(f"Unsupported file type: {path.suffix or 'none'}")
        return item
    try:
        raw = path.read_bytes()
    except OSError as exc:
        item["errors"].append(f"Unable to read file: {exc}")
        return item
    if not raw:
        item["errors"].append("File is empty.")
        return item
    item["sha256"] = hashlib.sha256(raw).hexdigest()
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        text = raw.decode("utf-8", errors="replace")
        item["warnings"].append("Bad UTF-8 bytes were replaced.")
    cleaned = clean(text)
    item["changed"] = cleaned != text
    item["suspicious_findings"] = flag(cleaned)
    dest = out_root / "processed_data" / rel.parent / f"{path.stem}_processed.txt"
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(cleaned, encoding="utf-8", newline="\n")
    item["output_file"] = str(dest.relative_to(out_root))
    item["status"] = "successful"
    return item


def main():
    ap = argparse.ArgumentParser(description="HeadWater ingestion demo (lite)")
    ap.add_argument("input", help="Folder or file to process")
    ap.add_argument("--output", default="demo_output", help="Output folder")
    args = ap.parse_args()

    src, out = Path(args.input), Path(args.output)
    if not src.exists():
        print(f"Input not found: {src}")
        return 2
    root = src if src.is_dir() else src.parent
    files = [src] if src.is_file() else sorted(p for p in src.rglob("*") if p.is_file())
    started = now()
    results = [handle(f, root, out) for f in files]
    ok = sum(r["status"] == "successful" for r in results)
    report = {
        "tool": "HeadWater ingestion demo (lite)",
        "started_utc": started, "completed_utc": now(), "input": str(src),
        "summary": {"files_discovered": len(results), "successful": ok,
                    "failed": len(results) - ok,
                    "suspicious_findings": sum(len(r["suspicious_findings"]) for r in results)},
        "results": results,
    }
    (out / "reports").mkdir(parents=True, exist_ok=True)
    (out / "reports" / "demo_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    s = report["summary"]
    print(f"Files: {s['files_discovered']}  OK: {s['successful']}  Failed: {s['failed']}  "
          f"Flagged: {s['suspicious_findings']}")
    print(f"Report: {out / 'reports' / 'demo_report.json'}")
    return 0 if s["failed"] == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
