---
pretty_name: HeadWater AI Data Ingestion Engine - Free Sample
license: other
license_name: headwater-free-sample-license
license_link: https://github.com/PunkiePal/HeadWater-AI-Digital-Products/blob/main/HEADWATER_FREE_SAMPLE_LICENSE.md
language:
  - en
tags:
  - data-cleaning
  - data-ingestion
  - text-preprocessing
  - preprocessing
  - json-report
  - sample
size_categories:
  - n<1K
viewer: false
---

# HeadWater AI Data Ingestion Engine: Free Sample

This is a free, runnable sample of what the HeadWater AI Data Ingestion Engine does to messy input files. It has a set of deliberately messy sample files, the real output the full engine produced from them, the JSON report, and a small demo script you can run yourself.

The full engine is a separate paid product and its code is not in this repo.

## What the engine does

You point it at a file or a folder. It:

1. Finds every file in the folder, including subfolders.
2. Cleans up text files: line endings, extra spaces and tabs, long runs of blank lines.
3. Strips company suffixes like Inc., LLC and Corp. from names.
4. Standardizes system parameter lines like `system parameter max retries = 5` into `SYSTEM_PARAMETER_MAX_RETRIES=5`.
5. Flags text that looks like instructions aimed at an AI (for example "ignore previous instructions") and hidden or invisible characters. It flags them for you to look at and does not delete them.
6. Writes the cleaned files plus a JSON report that lists every file, what happened to it, and why anything failed. One bad file does not stop the run.

Your original files are never changed.

## What's in this repo

| Path | What it is |
| --- | --- |
| `sample_input/` | 13 messy files: Windows line endings, odd spacing, bad encoding, an empty file, a fake PDF, hidden characters, a prompt-injection line, duplicates in subfolders |
| `engine_output/` | Real output from the full engine on `sample_input/`, including `reports/module_01_report.json` |
| `demo_lite.py` | A small script you can run. It does the line-ending and spacing cleanup, flags suspicious text and hidden characters, and writes a report. It does not do the company-name or system-parameter steps |
| `demo_output/` | What `demo_lite.py` produces |
| `HEADWATER_FREE_SAMPLE_LICENSE.md` | The HeadWater Free Sample License, Version 1.1, for this free sample |

## Run the demo

You need Python 3.8 or newer. Nothing else to install.

```
python3 demo_lite.py sample_input --output demo_output
```

It prints a one-line summary and writes `demo_output/reports/demo_report.json`. You can also point it at your own folder of text files.

## Before and after (real engine output)

Input `01_meeting_notes_crlf.txt` (Windows line endings, tabs, extra spaces, blank lines):

```
Weekly   sync		notes


Attendees:   Dana,  Luis,   Priya
Action items:	 follow up with Northwind Traders Inc. and Blue Harbor LLC
```

Output:

```
Weekly sync notes

Attendees: Dana, Luis, Priya
Action items: follow up with Northwind Traders and Blue Harbor
```

Input `03_config_dump.txt`:

```
system parameter max retries = 5
SYSTEM-PARAM-timeout = 30s
System Parameter log level=debug
region = us-west
```

Output (the `region` line is left alone because it is not a system parameter):

```
SYSTEM_PARAMETER_MAX_RETRIES=5
SYSTEM_PARAM_TIMEOUT=30s
SYSTEM_PARAMETER_LOG_LEVEL=debug
region = us-west
```

## The JSON report

Every run writes a report. The top of the report from this sample:

```json
"summary": {
  "files_discovered": 13,
  "successful": 11,
  "failed": 2,
  "warnings": 1,
  "transformations_applied": 26,
  "suspicious_findings": 4
}
```

Each file gets its own entry with its status, a SHA-256 hash of the original, how many characters went in and out, each change made, anything flagged, and any errors. In this sample the two failures are the empty file (`File is empty.`) and the PDF (`Unsupported file type: .pdf`). The prompt-injection file and the hidden-character file both succeed and carry flags for review.

## Things to know

- The engine processes `.txt`, `.md`, `.csv`, `.json`, `.xml`, `.html` and `.htm` files. Other types are listed in the report as failed.
- The company-suffix cleanup is a simple text rule. It works on names it can recognize but it can miss some and can occasionally take in an extra capitalized word before a name. Check the output before you rely on it.
- The sample files are made up. No real people, companies or data.

## Get the full engine

The full HeadWater AI Data Ingestion Engine is a one-time purchase with a perpetual license for one organization. It runs on your own machine and includes a simple desktop window as well as the command line.

- Product page: https://github.com/PunkiePal/HeadWater-AI-Digital-Products/blob/main/HeadWater%20AI%20Data%20Ingestion%20Engine.md
- Buy it on Payhip: https://payhip.com/b/lmFL9
- Questions: headwateraistudio@outlook.com

## License

This free sample is covered by the HeadWater Free Sample License, Version 1.1. The full text is in this package in `HEADWATER_FREE_SAMPLE_LICENSE.md`, and online at https://github.com/PunkiePal/HeadWater-AI-Digital-Products/blob/main/HEADWATER_FREE_SAMPLE_LICENSE.md

You can download, use and share this sample for free. If you share it, share the complete package unchanged and free of charge. It is not open-source software. The full engine has its own separate license.
